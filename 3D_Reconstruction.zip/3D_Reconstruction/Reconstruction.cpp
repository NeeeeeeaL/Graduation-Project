#include "Reconstruction.h"
#include "imageProcess.h"
#include "unwrap.h"
#include <QPainter>
#include <QtWidgets/QApplication>
#include <iostream>
#include <QFile>
#include <QLabel>
#include <QFileDialog>
#include <QDebug>
#include <QGridLayout>
#include <QTextCodec> //ת���ַ�ͷ�ļ�

#define cout qDebug() << "[" << __FILE__ << ":" << __LINE__ << "]"

QTextCodec *codecParent;

using namespace cv;
using namespace std;

//�����ڹ��캯��
Reconstruction::Reconstruction(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	//welcomeW.show();

	//��ʼ��codec
	codecParent = QTextCodec::codecForName("GBK");

	this->setWindowIcon(QIcon("myico.ico"));
	statusBar()->setStyleSheet(QString("QStatusBar::item{border: 0px}")); // ���ò���ʾlabel�ı߿�
	statusBar()->setSizeGripEnabled(false); //�����Ƿ���ʾ�ұߵĴ�С���Ƶ�
	statusBar()->addWidget(ui.labelStatus);
	ui.labelStatus->setText("Ready");

	//�������ƶ������ʵ�λ��
	this->move(120, 40);

	//����TabWidget�ĳ�ʼTab
	ui.tabWidget1->setCurrentIndex(0);
	ui.tabWidget2->setCurrentIndex(0);

	//�޸�toolbox��page����
	ui.toolBox->setItemText(0, codecParent->toUnicode("����Ҷ������"));
	ui.toolBox->setItemText(1, codecParent->toUnicode("����������"));
	//�޸�Tab����
	//ui.tabWidget1->setTabText(0, codecParent->toUnicode("ԭͼ"));
	//ui.tabWidget1->setTabText(1, codecParent->toUnicode("ԭͼ"));

	//�����Ӵ����ź�
	connect(&windowPMP, &PMPTrans::signalSwitch, this, &Reconstruction::dealChild);

}

//�����Ӵ��ڷ��͵���Ϣ
void Reconstruction::dealChild()
{
	windowPMP.hide();
	this->show();
}

//��ͼ�����о�����Ҫ���и��ӵ����ݴ���
//��Ϊ��ͼ�����ᱻƵ������
void Reconstruction::paintEvent(QPaintEvent *)
{
	QPainter p(this);//ָ��welcomeWΪ��ͼ�豸

	//�������ʶ���
	QPen pen;
	pen.setWidth(5);
	pen.setColor(QColor(0, 255, 0));

	//�ѱʽ�������
	p.setPen(pen);

	//��ͼ����
	//������ͼ
	//p.drawPixmap(0, 0, width(), height(), QPixmap("mouse.bmp"));//width(), height()�Զ���ȡ���ڿ��Ⱥ͸߶�
	p.fillRect(rect(), Qt::white);

	//������ˢ����
	QBrush brush;
	brush.setColor(Qt::green);
	brush.setStyle(Qt::Dense1Pattern);

	//�ѻ�ˢ��������
	p.setBrush(brush);	

}

//��QLabel����ʾMatͼ��
void Reconstruction::LabelDisplayMat(Mat & mat_img, QLabel * label)
{
	QImage img;
	if (mat_img.channels() == 3)//RGB image
	{
		cvtColor(mat_img, mat_img, CV_BGR2RGB); //Mat:BGR  //QImage:RGB
		img = QImage((const unsigned char*)(mat_img.data), mat_img.cols, mat_img.rows,
			mat_img.cols * mat_img.channels(), QImage::Format_RGB888);
	}
	else//Gray image
	{
		img = QImage((const unsigned char*)(mat_img.data), mat_img.cols, mat_img.rows,
			mat_img.cols * mat_img.channels(), QImage::Format_Indexed8);
	}
	QPixmap pixmap = QPixmap::fromImage(img);
	//QPixmap fitpixmap = pixmap.scaled(label->width(), label->height(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation); //�������
	QPixmap fitpixmap = pixmap.scaled(label->width(), label->height(), Qt::KeepAspectRatio, Qt::SmoothTransformation); //�ȱ������
	label->setPixmap(fitpixmap);
	label->setAlignment(Qt::AlignCenter);//ͼƬ������ʾ
}

//��ɢ����Ҷ�任
void Reconstruction::on_pushButton_clicked()
{
	connect(ui.pushButton, SIGNAL(clicked()), this, SLOT(on_pushButton_clicked));

	ui.statusBar->showMessage("Start the DFT transformation...", 1500);

	//����Ҷ�任
	imgOriginal_src.convertTo(imgOriginal_src, CV_64F, 1.0 / 255.0);//����Ҷ�任���������б����Ǹ�����
	imgModulated_src.convertTo(imgModulated_src, CV_64F, 1.0 / 255.0);

	ImageProcess imgDft;
	imgDft.fft2(imgOriginal_src, imgOriginal_fft);
	imgDft.fft2(imgModulated_src, imgModulated_fft);

	imgDft.fftshift(imgOriginal_fft);
	imgDft.fftshift(imgModulated_fft); //CV_64FC2

	Mat imgDisplay1;
	Mat imgDisplay2;

	imgDft.changeCh(imgOriginal_fft, imgDisplay1);
	imgDft.changeCh(imgModulated_fft, imgDisplay2);

	LabelDisplayMat(imgDisplay1, ui.labelImg1_2);
	LabelDisplayMat(imgDisplay2, ui.labelImg2_2);

	ui.tabWidget1->setCurrentIndex(1);
	ui.tabWidget2->setCurrentIndex(1);

}

//�˲�
void Reconstruction::on_pushButton_2_clicked()
{
	ui.statusBar->showMessage("Start to filt...", 1500);

	ImageProcess imgFilt;
	imgFilt.filt(imgOriginal_fft, imgOriginal_filt);
	imgFilt.filt(imgModulated_fft, imgModulated_filt);

	Mat imgDisplay1;
	Mat imgDisplay2;

	imgFilt.changeCh(imgOriginal_filt, imgDisplay1);
	imgFilt.changeCh(imgModulated_filt, imgDisplay2);

	cout << "imgOriginal_filt.type = " << imgOriginal_filt.type() << endl;
	
	LabelDisplayMat(imgDisplay1, ui.labelImg1_3);
	LabelDisplayMat(imgDisplay2, ui.labelImg2_3);

	ui.tabWidget1->setCurrentIndex(2);
	ui.tabWidget2->setCurrentIndex(2);

}

//����Ҷ���任
void Reconstruction::on_pushButton_3_clicked()
{
	ui.statusBar->showMessage("Start the IDFT transformation...", 1500);

	ImageProcess imgIfft;

	imgIfft.ifftshift(imgOriginal_filt);
	imgIfft.ifftshift(imgModulated_filt); //CV_64FC2

	imgIfft.ifft2(imgOriginal_filt, imgOriginal_ifft);
	imgIfft.ifft2(imgModulated_filt, imgModulated_ifft); //CV_64FC2

	Mat imgDisplay1;
	Mat imgDisplay2;

	vector<Mat> planes1;
	vector<Mat> planes2;

	split(imgOriginal_ifft, planes1);
	imgDisplay1 = planes1[0];

	split(imgModulated_ifft, planes2);
	imgDisplay2 = planes2[0];

	for (int i = 0; i < imgDisplay1.rows; ++i)
	{
		for (int j = 0; j < imgDisplay1.cols; ++j)
		{
			imgDisplay1.at<double>(i, j) *= 255;
			imgDisplay2.at<double>(i, j) *= 255;
		}
	}
	imgDisplay1.convertTo(imgDisplay1, CV_8U);
	imgDisplay2.convertTo(imgDisplay2, CV_8U);

	LabelDisplayMat(imgDisplay1, ui.labelImg1_4);
	LabelDisplayMat(imgDisplay2, ui.labelImg2_4);

	cout << "imgOriginal_ifft.type = " << imgOriginal_ifft.type() << endl;

	ui.tabWidget1->setCurrentIndex(3);
	ui.tabWidget2->setCurrentIndex(3);
	
}

//����λ
void Reconstruction::on_pushButton_4_clicked()
{
	ui.statusBar->showMessage("Start to obtain the angel...", 1500);

	Mat imgTmp1(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));
	Mat imgTmp2(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));

	//��͵��һ�㶼���У�����ֻ����һ��imgTmp�����������������������������ݻ���ͬ
	imgOriginal_angel = imgTmp1;
	imgModulated_angel = imgTmp2;//��imgModulated_angel����ֵ����������λʱ����
	
	vector<Mat> planes1;
	vector<Mat> planes2;

	split(imgOriginal_ifft, planes1);
	split(imgModulated_ifft, planes2);

	for (int i = 0; i < imgModulated_ifft.rows; ++i)
	{
		for (int j = 0; j < imgModulated_ifft.cols; ++j)
		{
			imgOriginal_angel.at<double>(i, j) =
				atan2(planes1[1].at<double>(i, j), planes1[0].at<double>(i, j));

			imgModulated_angel.at<double>(i, j) =
				atan2(planes2[1].at<double>(i, j), planes2[0].at<double>(i, j));
		}
	}

	/**************����***************/
	Mat imgTmp3(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));
	Mat imgTmp4(imgModulated_src.rows, imgModulated_src.cols, CV_32F, Scalar(0));
	Mat wrappedPhaseNormal(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));
	Mat unwrappedPhaseNormal(imgModulated_src.rows, imgModulated_src.cols, CV_32F, Scalar(0));

	wrappedPhase = imgTmp3;
	unwrappedPhase = imgTmp4;

	for (int i = 0; i < imgModulated_angel.rows; ++i)
	{
		for (int j = 0; j < imgModulated_angel.cols; ++j)
		{
			wrappedPhase.at<double>(i, j) =
				imgModulated_angel.at<double>(i, j) - imgOriginal_angel.at<double>(i, j);
		}
	}

	normalize(wrappedPhase, wrappedPhaseNormal, 0, 1, CV_MINMAX);
	//namedWindow("wrappedPhase", WINDOW_NORMAL);
	//resizeWindow("wrappedPhase", 700, 500);
	//imshow("wrappedPhase", wrappedPhaseNormal);

	//�����
	unwrap(wrappedPhase, unwrappedPhase);

	unwrappedPhase = abs(unwrappedPhase);
	normalize(unwrappedPhase, unwrappedPhaseNormal, 0, 1, CV_MINMAX);
	//namedWindow("unwrappedPhase", WINDOW_NORMAL);
	//resizeWindow("unwrappedPhase", 700, 500);
	//imshow("unwrappedPhase", unwrappedPhaseNormal);

	/****************���Խ���*****************/

	Mat imgDisplay1 = imgOriginal_angel;//CV_64F
	Mat imgDisplay2 = imgModulated_angel;//CV_64F

	int type = imgModulated_angel.type();

	cout << "type = " << type;

	//namedWindow("angel-1", WINDOW_NORMAL);
	//resizeWindow("angel-1", 700, 500);
	//imshow("angel-1", imgDisplay1);

	//namedWindow("angel-2", WINDOW_NORMAL);
	//resizeWindow("angel-2", 700, 500);
	//imshow("angel-2", imgDisplay2);

	for (int i = 0; i < imgDisplay1.rows; ++i)
	{
		for (int j = 0; j < imgDisplay1.cols; ++j)
		{
			imgDisplay1.at<double>(i, j) *= 255.0;
			imgDisplay2.at<double>(i, j) *= 255.0;
		}
	}

	imgDisplay1.convertTo(imgDisplay1, CV_8U);
	imgDisplay2.convertTo(imgDisplay2, CV_8U);

	LabelDisplayMat(imgDisplay1, ui.labelImg1_5);
	LabelDisplayMat(imgDisplay2, ui.labelImg2_5);

	ui.tabWidget1->setCurrentIndex(4);
	ui.tabWidget2->setCurrentIndex(4);

}

//����λ
void Reconstruction::on_pushButton_5_clicked()
{
	//Mat imgTmp1(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));
	//Mat imgTmp2(imgModulated_src.rows, imgModulated_src.cols, CV_32F, Scalar(0));
	//Mat wrappedPhaseNormal(imgModulated_src.rows, imgModulated_src.cols, CV_64F, Scalar(0));
	Mat unwrappedPhaseNormal(imgModulated_src.rows, imgModulated_src.cols, CV_32F, Scalar(0));

	//wrappedPhase = imgTmp1;
	//unwrappedPhase = imgTmp2;

	//for (int i = 0; i < imgModulated_angel.rows; ++i)
	//{
	//	for (int j = 0; j < imgModulated_angel.cols; ++j)
	//	{
	//		wrappedPhase.at<double>(i, j) =
	//			imgModulated_angel.at<double>(i, j) - imgOriginal_angel.at<double>(i, j);
	//	}
	//}

	//normalize(wrappedPhase, wrappedPhaseNormal, 0, 1, CV_MINMAX);
	////namedWindow("wrappedPhase", WINDOW_NORMAL);
	////resizeWindow("wrappedPhase", 700, 500);
	////imshow("wrappedPhase", wrappedPhaseNormal);

	////�����
	//unwrap(wrappedPhase, unwrappedPhase);

	//unwrappedPhase = abs(unwrappedPhase);
	normalize(unwrappedPhase, unwrappedPhaseNormal, 0, 1, CV_MINMAX);
	//namedWindow("unwrappedPhase", WINDOW_NORMAL);
	//resizeWindow("unwrappedPhase", 700, 500);
	//imshow("unwrappedPhase", unwrappedPhaseNormal);

	Mat imgDisplay = unwrappedPhaseNormal;

	for (int i = 0; i < imgDisplay.rows; ++i)
	{
		for (int j = 0; j < imgDisplay.cols; ++j)
		{
			imgDisplay.at<float>(i, j) *= 255;
		}
	}

	imgDisplay.convertTo(imgDisplay, CV_8U);

	LabelDisplayMat(imgDisplay, ui.labelImg1_6);
	LabelDisplayMat(imgDisplay, ui.labelImg2_6);

	ui.tabWidget1->setCurrentIndex(5);
	ui.tabWidget2->setCurrentIndex(5);
}

//��ͼƬ
void Reconstruction::on_actionOpen_triggered()
{
	connect(ui.actionOpen, SIGNAL(triggered()), this, SLOT(on_actionOpen_triggered));

	//��ԭͼ��
	QStringList pathList = QFileDialog::getOpenFileNames(this, "open", "../");//�������ļ�
	for (int i = 0; i < pathList.size(); ++i)
	{
		if (false == pathList[i].isEmpty())
		{
			//����QFile����
			QFile file(pathList[i]);

			//����QFileInfo���󣬻�ȡ�ļ���
			QFileInfo fileInfo(file);

			QString imgName = fileInfo.fileName();

			//״̬����ʾ
			ui.statusBar->showMessage("Open " + imgName + " successfully! Path: " + fileInfo.path(), 1500);

			if (i == 0)
			{
				imgOriginal_src = imread("..\\image\\" + imgName.toStdString(), 0);
				LabelDisplayMat(imgOriginal_src, ui.labelImg1_1);
				cout << "Read imgOriginal_src successfully!" << endl;
			}
			else
			{
				imgModulated_src = imread("..\\image\\" + imgName.toStdString(), 0);
				LabelDisplayMat(imgModulated_src, ui.labelImg2_1);
				cout << "Read imgModulated_src successfully!" << endl;
			}

		}
	}

}

//����ͼƬ
void Reconstruction::on_actionSave_triggered()
{
	connect(ui.actionSave, SIGNAL(triggered()), this, SLOT(on_actionSave_triggered));

	QString path = QFileDialog::getSaveFileName(this, "save", "../", "Images(*.png);;Images(*.bmp);;Images(*.jpg)");

	if (false == path.isEmpty())
	{
		QFile file(path);

		bool isOk = file.open(QIODevice::WriteOnly);
		if (true == isOk)
		{
			//QImage img = QImage((const unsigned char*)(mouse1Img.data), mouse1Img.cols, mouse1Img.rows,
			//	mouse1Img.cols * mouse1Img.channels(), QImage::Format_RGB888);
			//QPixmap pixmap = QPixmap::fromImage(img);

			////pixmap.save(path, "png", 0);
			//imwrite(path.toStdString(), mouse1Img);
		}

		file.close();
	}
}

//�л����Ӵ���
void Reconstruction::on_actionPMP_triggered()
{
	windowPMP.show();
	this->hide();
}

