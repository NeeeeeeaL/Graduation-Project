/********************************************************************************
** Form generated from reading UI file 'cube.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUBE_H
#define UI_CUBE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Cube
{
public:
    QLabel *label;

    void setupUi(QWidget *Cube)
    {
        if (Cube->objectName().isEmpty())
            Cube->setObjectName(QStringLiteral("Cube"));
        Cube->resize(1550, 800);
        label = new QLabel(Cube);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(1270, 200, 384, 384));
        label->setStyleSheet(QLatin1String("QLabel{background-image: url(:/Reconstruction/Resources/cube.png)}\n"
""));

        retranslateUi(Cube);

        QMetaObject::connectSlotsByName(Cube);
    } // setupUi

    void retranslateUi(QWidget *Cube)
    {
        Cube->setWindowTitle(QApplication::translate("Cube", "Cube", Q_NULLPTR));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Cube: public Ui_Cube {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUBE_H
