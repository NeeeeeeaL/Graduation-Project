/********************************************************************************
** Form generated from reading UI file 'pmpTrans.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PMPTRANS_H
#define UI_PMPTRANS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PMPTrans
{
public:
    QAction *actionFTP;
    QAction *actionOpen;
    QAction *actionSave;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menuSwitchTo;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *PMPTrans)
    {
        if (PMPTrans->objectName().isEmpty())
            PMPTrans->setObjectName(QStringLiteral("PMPTrans"));
        PMPTrans->resize(1440, 960);
        QFont font;
        font.setFamily(QString::fromUtf8(".\350\213\271\346\226\271-\347\256\200"));
        PMPTrans->setFont(font);
        actionFTP = new QAction(PMPTrans);
        actionFTP->setObjectName(QStringLiteral("actionFTP"));
        actionOpen = new QAction(PMPTrans);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionSave = new QAction(PMPTrans);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        centralWidget = new QWidget(PMPTrans);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        PMPTrans->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(PMPTrans);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1440, 27));
        menuSwitchTo = new QMenu(menuBar);
        menuSwitchTo->setObjectName(QStringLiteral("menuSwitchTo"));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        PMPTrans->setMenuBar(menuBar);
        mainToolBar = new QToolBar(PMPTrans);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        PMPTrans->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(PMPTrans);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        PMPTrans->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuSwitchTo->menuAction());
        menuSwitchTo->addAction(actionFTP);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        mainToolBar->addAction(actionOpen);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionSave);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionFTP);
        mainToolBar->addSeparator();

        retranslateUi(PMPTrans);

        QMetaObject::connectSlotsByName(PMPTrans);
    } // setupUi

    void retranslateUi(QMainWindow *PMPTrans)
    {
        PMPTrans->setWindowTitle(QApplication::translate("PMPTrans", "PMPTrans", Q_NULLPTR));
        actionFTP->setText(QApplication::translate("PMPTrans", "FTP", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("PMPTrans", "Open", Q_NULLPTR));
        actionSave->setText(QApplication::translate("PMPTrans", "Save", Q_NULLPTR));
        menuSwitchTo->setTitle(QApplication::translate("PMPTrans", "SwitchTo", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("PMPTrans", "File", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class PMPTrans: public Ui_PMPTrans {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PMPTRANS_H
