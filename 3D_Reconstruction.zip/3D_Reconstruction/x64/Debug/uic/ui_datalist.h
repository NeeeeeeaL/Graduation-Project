/********************************************************************************
** Form generated from reading UI file 'datalist.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DATALIST_H
#define UI_DATALIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DataList
{
public:
    QTableView *tableView;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QPushButton *pushButton_2;
    QLabel *label_3;

    void setupUi(QWidget *DataList)
    {
        if (DataList->objectName().isEmpty())
            DataList->setObjectName(QStringLiteral("DataList"));
        DataList->resize(1550, 800);
        QFont font;
        font.setFamily(QString::fromUtf8(".\350\213\271\346\226\271-\347\256\200"));
        DataList->setFont(font);
        tableView = new QTableView(DataList);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 60, 1331, 581));
        QFont font1;
        font1.setFamily(QString::fromUtf8(".\350\213\271\346\226\271-\347\256\200"));
        font1.setPointSize(9);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(3);
        tableView->setFont(font1);
        tableView->setStyleSheet(QString::fromUtf8("QTableView {\n"
"    color: black;                                       /*\350\241\250\346\240\274\345\206\205\346\226\207\345\255\227\351\242\234\350\211\262*/\n"
"    gridline-color: black;                              /*\350\241\250\346\240\274\345\206\205\346\241\206\351\242\234\350\211\262*/\n"
"    background-color: rgb(255, 255, 255);               /*\350\241\250\346\240\274\345\206\205\350\203\214\346\231\257\350\211\262*/\n"
"    alternate-background-color: rgb(198, 198, 198);\n"
"    selection-color: black;                             /*\351\200\211\344\270\255\345\214\272\345\237\237\347\232\204\346\226\207\345\255\227\351\242\234\350\211\262*/\n"
"    selection-background-color: rgb(198, 198, 198);        /*\351\200\211\344\270\255\345\214\272\345\237\237\347\232\204\350\203\214\346\231\257\350\211\262*/\n"
"    border: 2px black;\n"
"    border-radius: 2px;\n"
"    padding: 2px 4px;\n"
"	font: 25 9pt \".\350\213\271\346\226\271-\347\256\200\";\n"
"}\n"
"\n"
"QHeaderView {\n"
"    color: black;\n"
""
                        "    background-color: white;\n"
"    border: 1px solid rgb(144, 144, 144);\n"
"    border-left-color: rgba(255, 255, 255, 0);\n"
"    border-top-color: rgba(255, 255, 255, 0);\n"
"    border-radius:0px;\n"
"    min-height:30px;\n"
"	min-width:25px;\n"
"	font: 25 9pt \".\350\213\271\346\226\271-\347\256\200\";\n"
"}\n"
"\n"
"QTableView QTableCornerButton::section {\n"
"\n"
"    color: red;\n"
"    background-color: white;\n"
"    border: 0px solid #f6f7fa;\n"
"    border-radius:0px;\n"
"    border-color: rgb(64, 64, 64);\n"
" }\n"
"\n"
""));
        pushButton = new QPushButton(DataList);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(610, 740, 93, 28));
        lineEdit = new QLineEdit(DataList);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(230, 740, 113, 21));
        label_2 = new QLabel(DataList);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(130, 740, 72, 15));
        pushButton_2 = new QPushButton(DataList);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(380, 740, 93, 28));
        label_3 = new QLabel(DataList);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(1240, 200, 384, 384));
        label_3->setStyleSheet(QLatin1String("QLabel{border-image: url(:/Reconstruction/Resources/stats.png)}\n"
""));
        pushButton->raise();
        lineEdit->raise();
        label_2->raise();
        pushButton_2->raise();
        label_3->raise();
        tableView->raise();

        retranslateUi(DataList);

        QMetaObject::connectSlotsByName(DataList);
    } // setupUi

    void retranslateUi(QWidget *DataList)
    {
        DataList->setWindowTitle(QApplication::translate("DataList", "DataList", Q_NULLPTR));
        pushButton->setText(QApplication::translate("DataList", "\346\237\245\350\257\242\346\225\260\346\215\256\345\272\223", Q_NULLPTR));
        label_2->setText(QApplication::translate("DataList", "\346\225\260\346\215\256\346\237\245\350\257\242\357\274\232", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("DataList", "\346\237\245\350\257\242", Q_NULLPTR));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DataList: public Ui_DataList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DATALIST_H
