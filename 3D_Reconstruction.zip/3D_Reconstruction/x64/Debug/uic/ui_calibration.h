/********************************************************************************
** Form generated from reading UI file 'calibration.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALIBRATION_H
#define UI_CALIBRATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Calibration
{
public:
    QLabel *label;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label4;
    QLabel *label9;
    QLabel *label3;
    QLabel *label10;
    QLabel *label11;
    QLabel *label8;
    QLabel *label7;
    QLabel *label12;
    QLabel *label2;
    QLabel *label1;
    QLabel *label6;
    QLabel *label5;
    QWidget *tab_2;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QLabel *label4_2;
    QLabel *label9_2;
    QLabel *label3_2;
    QLabel *label10_2;
    QLabel *label11_2;
    QLabel *label8_2;
    QLabel *label7_2;
    QLabel *label12_2;
    QLabel *label2_2;
    QLabel *label1_2;
    QLabel *label6_2;
    QLabel *label5_2;

    void setupUi(QWidget *Calibration)
    {
        if (Calibration->objectName().isEmpty())
            Calibration->setObjectName(QStringLiteral("Calibration"));
        Calibration->resize(1580, 800);
        QFont font;
        font.setFamily(QString::fromUtf8(".\350\213\271\346\226\271-\347\256\200"));
        Calibration->setFont(font);
        Calibration->setAutoFillBackground(false);
        label = new QLabel(Calibration);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(1270, 200, 384, 384));
        label->setStyleSheet(QLatin1String("QLabel{border-image: url(:/Reconstruction/Resources/checkered.png)}\n"
""));
        pushButton1 = new QPushButton(Calibration);
        pushButton1->setObjectName(QStringLiteral("pushButton1"));
        pushButton1->setGeometry(QRect(1430, 620, 111, 41));
        pushButton1->setFont(font);
        pushButton2 = new QPushButton(Calibration);
        pushButton2->setObjectName(QStringLiteral("pushButton2"));
        pushButton2->setGeometry(QRect(1430, 690, 111, 41));
        pushButton2->setFont(font);
        tabWidget = new QTabWidget(Calibration);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(30, 50, 1371, 751));
        tabWidget->setFont(font);
        tabWidget->setStyleSheet(QString::fromUtf8("QTabWidget::tab-bar{ alignment: center;}\n"
"QTabBar::tab:selected{ background-color: rgb(0, 122, 255);color: white; }\n"
"\n"
"QTabBar::tab{ width: 120px; height:25px; border-radius: 4px; margin-bottom: 6px;}\342\200\213"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayoutWidget = new QWidget(tab);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(50, 10, 1281, 691));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label4 = new QLabel(gridLayoutWidget);
        label4->setObjectName(QStringLiteral("label4"));

        gridLayout->addWidget(label4, 0, 3, 1, 1);

        label9 = new QLabel(gridLayoutWidget);
        label9->setObjectName(QStringLiteral("label9"));

        gridLayout->addWidget(label9, 3, 0, 1, 1);

        label3 = new QLabel(gridLayoutWidget);
        label3->setObjectName(QStringLiteral("label3"));

        gridLayout->addWidget(label3, 0, 2, 1, 1);

        label10 = new QLabel(gridLayoutWidget);
        label10->setObjectName(QStringLiteral("label10"));

        gridLayout->addWidget(label10, 3, 1, 1, 1);

        label11 = new QLabel(gridLayoutWidget);
        label11->setObjectName(QStringLiteral("label11"));

        gridLayout->addWidget(label11, 3, 2, 1, 1);

        label8 = new QLabel(gridLayoutWidget);
        label8->setObjectName(QStringLiteral("label8"));

        gridLayout->addWidget(label8, 2, 3, 1, 1);

        label7 = new QLabel(gridLayoutWidget);
        label7->setObjectName(QStringLiteral("label7"));

        gridLayout->addWidget(label7, 2, 2, 1, 1);

        label12 = new QLabel(gridLayoutWidget);
        label12->setObjectName(QStringLiteral("label12"));

        gridLayout->addWidget(label12, 3, 3, 1, 1);

        label2 = new QLabel(gridLayoutWidget);
        label2->setObjectName(QStringLiteral("label2"));

        gridLayout->addWidget(label2, 0, 1, 1, 1);

        label1 = new QLabel(gridLayoutWidget);
        label1->setObjectName(QStringLiteral("label1"));

        gridLayout->addWidget(label1, 0, 0, 1, 1);

        label6 = new QLabel(gridLayoutWidget);
        label6->setObjectName(QStringLiteral("label6"));

        gridLayout->addWidget(label6, 2, 1, 1, 1);

        label5 = new QLabel(gridLayoutWidget);
        label5->setObjectName(QStringLiteral("label5"));

        gridLayout->addWidget(label5, 2, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        gridLayoutWidget_2 = new QWidget(tab_2);
        gridLayoutWidget_2->setObjectName(QStringLiteral("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(50, 10, 1281, 691));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label4_2 = new QLabel(gridLayoutWidget_2);
        label4_2->setObjectName(QStringLiteral("label4_2"));
        label4_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label4_2, 0, 3, 1, 1);

        label9_2 = new QLabel(gridLayoutWidget_2);
        label9_2->setObjectName(QStringLiteral("label9_2"));
        label9_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label9_2, 3, 0, 1, 1);

        label3_2 = new QLabel(gridLayoutWidget_2);
        label3_2->setObjectName(QStringLiteral("label3_2"));
        label3_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label3_2, 0, 2, 1, 1);

        label10_2 = new QLabel(gridLayoutWidget_2);
        label10_2->setObjectName(QStringLiteral("label10_2"));
        label10_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label10_2, 3, 1, 1, 1);

        label11_2 = new QLabel(gridLayoutWidget_2);
        label11_2->setObjectName(QStringLiteral("label11_2"));
        label11_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label11_2, 3, 2, 1, 1);

        label8_2 = new QLabel(gridLayoutWidget_2);
        label8_2->setObjectName(QStringLiteral("label8_2"));
        label8_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label8_2, 2, 3, 1, 1);

        label7_2 = new QLabel(gridLayoutWidget_2);
        label7_2->setObjectName(QStringLiteral("label7_2"));
        label7_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label7_2, 2, 2, 1, 1);

        label12_2 = new QLabel(gridLayoutWidget_2);
        label12_2->setObjectName(QStringLiteral("label12_2"));
        label12_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label12_2, 3, 3, 1, 1);

        label2_2 = new QLabel(gridLayoutWidget_2);
        label2_2->setObjectName(QStringLiteral("label2_2"));
        label2_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label2_2, 0, 1, 1, 1);

        label1_2 = new QLabel(gridLayoutWidget_2);
        label1_2->setObjectName(QStringLiteral("label1_2"));
        label1_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label1_2, 0, 0, 1, 1);

        label6_2 = new QLabel(gridLayoutWidget_2);
        label6_2->setObjectName(QStringLiteral("label6_2"));
        label6_2->setMinimumSize(QSize(264, 225));

        gridLayout_2->addWidget(label6_2, 2, 1, 1, 1);

        label5_2 = new QLabel(gridLayoutWidget_2);
        label5_2->setObjectName(QStringLiteral("label5_2"));
        label5_2->setMinimumSize(QSize(265, 225));

        gridLayout_2->addWidget(label5_2, 2, 0, 1, 1);

        tabWidget->addTab(tab_2, QString());

        retranslateUi(Calibration);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Calibration);
    } // setupUi

    void retranslateUi(QWidget *Calibration)
    {
        Calibration->setWindowTitle(QApplication::translate("Calibration", "Calibration", Q_NULLPTR));
        label->setText(QString());
        pushButton1->setText(QApplication::translate("Calibration", "\350\257\273\345\217\226\346\240\207\345\256\232\345\233\276\345\203\217", Q_NULLPTR));
        pushButton2->setText(QApplication::translate("Calibration", "\346\240\207\345\256\232", Q_NULLPTR));
        label4->setText(QString());
        label9->setText(QString());
        label3->setText(QString());
        label10->setText(QString());
        label11->setText(QString());
        label8->setText(QString());
        label7->setText(QString());
        label12->setText(QString());
        label2->setText(QString());
        label1->setText(QString());
        label6->setText(QString());
        label5->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("Calibration", "\346\240\207\345\256\232\345\233\276\345\203\217", Q_NULLPTR));
        label4_2->setText(QString());
        label9_2->setText(QString());
        label3_2->setText(QString());
        label10_2->setText(QString());
        label11_2->setText(QString());
        label8_2->setText(QString());
        label7_2->setText(QString());
        label12_2->setText(QString());
        label2_2->setText(QString());
        label1_2->setText(QString());
        label6_2->setText(QString());
        label5_2->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Calibration", "\347\237\253\346\255\243\347\225\270\345\217\230\345\220\216\345\233\276\345\203\217", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Calibration: public Ui_Calibration {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALIBRATION_H
