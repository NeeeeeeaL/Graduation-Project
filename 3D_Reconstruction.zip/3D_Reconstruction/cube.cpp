#include "cube.h"

Cube::Cube(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

Cube::~Cube()
{
}
